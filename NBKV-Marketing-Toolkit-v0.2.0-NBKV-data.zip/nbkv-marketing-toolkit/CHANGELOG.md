# Changelog

## 0.2.0 — NBKV business-context release

- Added NBKV Digital Growth profile, services, website, business contact, and campaign-planning context.
- Added editable Vijayawada lead-generation defaults (business owners, ages 25–45; Telugu and English planning context).
- Added daily budget split planner with the illustrative ₹500/day 70/30 example.
- Prefilled UTM builder with the NBKV website and a sample lead-generation campaign.
- Kept all campaign inputs local to the browser.

## 0.1.0 — Initial project draft

- Added UTM link builder.
- Added Meta Ads and Google Ads campaign naming helper.
- Added CTR, CPC, CPM, and cost-per-lead calculator.
- Added project documentation, contribution guidelines, and MIT license.
