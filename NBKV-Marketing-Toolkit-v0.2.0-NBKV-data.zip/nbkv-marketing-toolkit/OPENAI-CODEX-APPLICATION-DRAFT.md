# OpenAI Codex for Open Source — Application Preparation Draft

**Status: Not ready to submit.** This file records known profile data and flags fields that require actual open-source project evidence. Do not submit until the repository is public, actively maintained, and its usage/importance can be demonstrated.

## Known account details

- First name: Naga Babu
- Last name: Vemula
- GitHub username: `nbkvdigitalgrowth`
- GitHub profile: https://github.com/nbkvdigitalgrowth
- GitHub-connected account email returned by the connection: `nagababuv56@gmail.com`
  - **Confirm this is also the email associated with the ChatGPT account before entering it.**

## Fields that must be completed only after verification

- GitHub repository URL: pending publication of `nbkv-marketing-toolkit`
- Maintainer role: not yet evidenced; do not select Primary/Core Maintainer until you have actually maintained the public project and can substantiate that role.
- Why does this repository qualify? Not ready. Gather real GitHub stars, downloads/usage, releases, external users, issues/PRs, and examples of ecosystem value. A newly created repository with no adoption may not satisfy the program criteria.
- I'm interested in: select the applicable options on the live form after reviewing them.
- OpenAI Organization ID: retrieve from the OpenAI Platform organization settings; this is not the GitHub ID and must not be guessed.

## Draft: API credits usage (use only after the project has a real maintenance workflow)

I plan to use OpenAI API credits to support the maintenance of NBKV Marketing Toolkit through documentation assistance, test generation, issue triage, and safe review of proposed code changes. The goal is to reduce repetitive maintenance work, improve reliability and accessibility, and make practical campaign-planning utilities easier for marketers and small businesses to use. All use will follow the project's privacy principles and will not send user campaign data without consent.

## Draft: Anything else (optional)

NBKV Digital Growth focuses on performance marketing and lead generation through Meta Ads, Google Ads, WhatsApp marketing, and local SEO. This toolkit turns recurring campaign setup and reporting workflows into small, privacy-first utilities that can be adapted by freelancers, agencies, and small businesses. I intend to maintain the project transparently and welcome contributions from the wider community.

## Final pre-submit checklist

- [ ] Repository is public and accessible without login.
- [ ] README explains purpose, setup, privacy, and contribution process.
- [ ] License is present and compatible with the project.
- [ ] You have made and documented real maintenance contributions.
- [ ] Claims about stars, users, downloads, releases, or impact are accurate and verifiable.
- [ ] Maintainer role accurately reflects your responsibilities.
- [ ] ChatGPT account email is confirmed.
- [ ] OpenAI Organization ID is copied from the correct OpenAI Platform organization.
