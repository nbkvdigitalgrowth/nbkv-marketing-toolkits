# NBKV Marketing Toolkit

A free, browser-based set of utilities for performance marketers, freelancers, agencies, and small businesses. This project is prepared for publication under the NBKV Digital Growth brand.

**Tagline:** Your Growth, Our Mission  
**Website:** https://nbkvgrowth.digital  
**Business contact:** contact@nbkvgrowth.digital

## NBKV business context used in the defaults

- **Brand:** NBKV Digital Growth
- **Services:** Meta Ads, Google Ads, WhatsApp marketing, lead generation, and local SEO
- **Primary local-market example:** Vijayawada, including Benz Circle and a configurable 15–20 km starting radius
- **Common lead-generation audience example:** business owners, ages 25–45
- **Languages used in campaign planning:** Telugu and English
- **Illustrative budget split:** ₹500/day, with ₹350 for a primary campaign and ₹150 for testing (70/30)

These are editable starting assumptions based on NBKV's prior campaign-planning context, not universal targeting or budget recommendations. Review them for each client and campaign. Do not put any client's private data into a public issue or commit.

## Tools included

- **UTM Link Builder:** adds `utm_source`, `utm_medium`, `utm_campaign`, `utm_term`, and `utm_content` to a destination URL while preserving existing query parameters. The form opens with NBKV's website and a Vijayawada lead-generation example; users can replace them.
- **Ad Campaign Naming Helper:** creates consistent Meta Ads and Google Ads campaign names using platform, objective, location, audience, creative type, date, and version.
- **Daily Budget Split Planner:** splits a daily budget between primary and testing campaigns. The default is NBKV's illustrative ₹500/day 70/30 planning example.
- **Campaign KPI Calculator:** calculates CTR, CPC, CPM, and cost per lead from user-entered values.

## Run locally

No build step, package manager, backend, or API key is required.

1. Download or clone this repository.
2. Open `index.html` in a modern browser.
3. Use the tools. Inputs are processed in the browser.

For local development, a simple static server is also fine:

```bash
python -m http.server 8000
```

Then open `http://localhost:8000`.

## Privacy

The app has no backend, analytics, ad pixels, external JavaScript dependencies, or network requests initiated by the tools. Values entered into forms remain in the browser unless a user copies or shares the generated output.

## Limitations

- KPI results are arithmetic based on user-supplied values, not performance benchmarks or predictions.
- Budget and targeting defaults are examples and must be adjusted for each client.
- The toolkit is not affiliated with Meta, Google, or OpenAI.

## Contributing

Bug reports, feature suggestions, documentation improvements, and pull requests are welcome. See [CONTRIBUTING.md](CONTRIBUTING.md).

## License

MIT. See [LICENSE](LICENSE).

## Project owner / contact

NBKV Digital Growth — https://github.com/nbkvdigitalgrowth
